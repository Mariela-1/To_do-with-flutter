import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

class TaskListScreen extends StatefulWidget {
  const TaskListScreen({super.key});

  @override
  State<TaskListScreen> createState() => _TaskListScreenState();
}

class _TaskListScreenState extends State<TaskListScreen> {
  List<String> tasks = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 238, 187, 247),
      appBar: AppBar(
        centerTitle: true,
        title: const Text("To Do"),
        backgroundColor: Colors.purple,
      ),
      body: ListView.builder(
        itemCount: tasks.length,
        itemBuilder: (context, index) {
          return Container(
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 243, 124, 243),
              border: Border.all(
                // Color del borde
                color: const Color.fromARGB(255, 255, 255, 255),
                width: 1.0,
              ),
              borderRadius:
                  BorderRadius.circular(8.0), // Radio de las esquinas del borde
            ),
            margin: const EdgeInsets.symmetric(
                vertical: 4.0,
                horizontal: 8.0), // Márgenes alrededor de cada contenedor

            child: TaskItem(
              task: tasks[index],
              onUpdate: (newTask) {
                setState(() {
                  tasks[index] = newTask;
                });
              },
              onDelete: () {
                setState(() {
                  tasks.removeAt(index);
                });
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => TaskScreen(
                callback: (name) {
                  setState(() {
                    tasks.add(name);
                  });
                },
              ),
            ),
          );
        },
        child: const Icon(
          Icons.add,
          color: Colors.purple,
        ),
      ),
    );
  }
}

class TaskItem extends StatefulWidget {
  const TaskItem({
    super.key,
    required this.task,
    required this.onUpdate,
    required this.onDelete,
  });

  final String task;
  final Function(String) onUpdate;
  final Function() onDelete;

  @override
  State<TaskItem> createState() => _TaskItemState();
}

class _TaskItemState extends State<TaskItem> {
  bool isChecked = false;
  bool isEditing = false;
  late TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.task);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Slidable(
      endActionPane: ActionPane(
        motion: const StretchMotion(),
        children: [
          SlidableAction(
            onPressed: (context) => widget.onDelete(),
            icon: Icons.delete,
            backgroundColor: Colors.red.shade300,
            label: 'Delete',
          ),
        ],
      ),
      child: ListTile(
        title: isEditing
            ? TextField(
                controller: _controller,
                style: isChecked
                    ? const TextStyle(
                        decoration: TextDecoration.lineThrough,
                        color: Colors.white)
                    : null,
                onSubmitted: (newValue) {
                  setState(() {
                    isEditing = false;
                  });
                  widget.onUpdate(newValue);
                },
                autofocus: true,
              )
            : GestureDetector(
                onDoubleTap: () {
                  setState(() {
                    isEditing = true;
                  });
                },
                child: Text(
                  _controller.text,
                  style: isChecked
                      ? const TextStyle(decoration: TextDecoration.lineThrough)
                      : null,
                ),
              ),
        trailing: Checkbox(
          onChanged: (value) {
            setState(() {
              isChecked = value!;
            });
          },
          value: isChecked,
        ),
      ),
    );
  }
}

class TaskScreen extends StatelessWidget {
  TaskScreen({super.key, required this.callback});

  final TextEditingController _controller = TextEditingController();
  final Function(String) callback;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextField(
            controller: _controller,
            decoration: InputDecoration(
              label: const Text(
                "Task name",
                style: TextStyle(color: Colors.purple),
              ),
              filled: true,
              fillColor: Colors.purple[50],
              border: const OutlineInputBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(4),
                ),
              ),
              enabledBorder: const OutlineInputBorder(
                borderSide: BorderSide(color: Colors.purple),
                borderRadius: BorderRadius.all(
                  Radius.circular(4),
                ),
              ),
              focusedBorder: const OutlineInputBorder(
                borderSide: BorderSide(color: Colors.purpleAccent),
                borderRadius: BorderRadius.all(
                  Radius.circular(4),
                ),
              ),
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          String name = _controller.text;
          callback(name);
          Navigator.pop(context);
        },
        child: const Icon(
          Icons.save,
          color: Colors.purple,
        ),
      ),
    );
  }
}
